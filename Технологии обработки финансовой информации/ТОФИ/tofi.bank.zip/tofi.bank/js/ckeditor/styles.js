CKEDITOR.addStylesSet( 'GF',
[
	{
		name: 'Image on left',
		element: 'img',
		attributes:
		{
			'style': 'float:left; margin:5px 0 10px 0;',
			'border': '0',
			'align': 'left'
		}
	},
	{
		name: 'Image on right',
		element: 'img',
		attributes:
		{
			'style': 'float:right; margin:5px 0 10px 30px;',
			'border': '0',
			'align': 'right'
		}
	}
]);