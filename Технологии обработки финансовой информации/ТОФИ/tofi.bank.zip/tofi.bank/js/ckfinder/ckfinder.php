<?php
	require_once 'core/ckfinder_php5.php' ;