<?php
abstract class AdminBlock extends BaseBlock
{
	/**
	 * @var string
	 */
	protected $controlerPath = BLOCKS_ADMIN;
}