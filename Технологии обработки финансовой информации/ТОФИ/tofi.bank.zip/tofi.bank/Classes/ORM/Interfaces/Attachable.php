<?php

interface Attachable 
{
	/**
	 * @return array
	 */
	public function getFields();
}