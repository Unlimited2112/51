<?php
class ApplicationsPage extends ModelTemplate
{
	public function __construct()
	{
		parent::__construct('Applications');
	}
}